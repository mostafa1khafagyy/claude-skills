---
name: session-handoff
description: Use this skill when the user wants to end a chat session cleanly and resume in a new one without losing context. Trigger on explicit phrases like "session handoff", "handoff this", "do a session handoff", "wrap this session", "run the session handoff skill", and natural-language signals like "this chat is getting too long", "I need to start a new chat", "summarise this for a new session", "I'm running out of context", "before /clear", "before /compact", or "I'm switching to a new chat". Generates a structured continuation document — tagged by project, scoped to session delta (not long-term memory), with literal next-step commands, blockers, open decisions, and file state. Activate aggressively whenever any of these phrases appear, even mid-task.
---

# Session Handoff

Generate a continuation document so the next Claude session resumes exactly where this one stopped — with zero re-explanation.

## Core principle: capture the DELTA, not the world

Long-term memory already carries the user's ventures, tech stack, working style, and ongoing project state. **DO NOT restate any of this.** The handoff captures only what changed in THIS chat and what the next session needs to keep going.

If a section has nothing to report from this chat, write `N/A`. Never invent. Never pad. Brevity is correct.

---

## Step 1: Identify the resume target

Scan the chat for signals:

- File paths, bash/PowerShell commands run, file edits made, code blocks executed → **Claude Code target** → output as a file to write to `tasks/handoff.md`
- Strategy discussion, planning, content drafting, no actual file edits → **Claude.ai target** → output as a paste-ready code block

If ambiguous, ask once: *"Resume target — Claude.ai chat or Claude Code session?"* Then proceed. Do not guess.

## Step 2: Identify the project

Determine which single project this chat is about. Look at file paths, repo names, named entities, dollar amounts, supplier names, or anything else that identifies a distinct project.

If the chat clearly spans more than one project, ask: *"This chat covered [X] and [Y] — handoff for which? Or do you want separate handoffs?"* Do not merge unrelated projects into one handoff.

If unclear which single project, ask: *"Which project does this handoff belong to?"*

## Step 3: Fill the handoff structure

Use this exact structure. Empty fields get `N/A`.

```
## Session Handoff — [Project Name]

### Resume Target
[Claude.ai chat / Claude Code @ <repo path>]

### Session Goal
One sentence. What this chat was trying to accomplish.

### What Got Done
Specific completions only.
- [Concrete thing 1]
- [Concrete thing 2]

### Decisions Made This Session
Choices locked in during this chat — not pre-existing ones from memory.
- [Decision + brief reasoning if non-obvious]

### Files Touched
(Claude Code only — skip if Claude.ai target)
- `exact/path/to/file.ts` — added X, uncommitted
- `exact/path/to/file2.md` — replaced section Y, committed

### Exact Next Step
Be literal to a fault. Not "continue with the migration." Instead:
- **Command:** `<exact command to run>`
- **Path:** `<exact directory or file>`
- **Expected result:** `<what should appear>`
- **If clicking:** `<exact button / dashboard URL>`

### Open Decisions
Choices that were under discussion but not locked.
- [Pending choice + the trade-off in one line]

### Blockers / Waiting On
External dependencies that need chasing.
- [Who/what + since when + next chase action]

### Dead Ends
Approaches tried and ruled out THIS chat. Don't redo these.
- [Approach + why ruled out]

### Operating Notes for Next Session
How to continue this specific work. E.g. "stay in PowerShell, not WSL"; "workflow is mid-build, do not /clear before saving"; "user is on mobile right now, keep commands short."
```

## Step 4: Output format by target

**Claude.ai target:**
Wrap the entire structure in a single fenced markdown code block so the user can select-all and paste into the next chat. No text before or after the code block.

**Claude Code target:**
Output the structure as raw markdown (no outer code fence). Below it, give the exact save command for the user's environment based on chat signals.

For PowerShell on Windows:
```
Set-Content -Path tasks\handoff.md -Value @'
<paste content here>
'@
```

For bash/zsh:
```
cat > tasks/handoff.md << 'EOF'
<paste content here>
EOF
```

Pick the one matching the user's environment based on chat context cues. If unclear, default to the shell most recently used in the chat.

---

## Hard rules

- **NEVER restate facts already in long-term memory.** Ventures, stack, location, working style — all already loaded. Mentioning them is padding.
- **NEVER pad.** `N/A` is the correct value for an empty section. An honest sparse handoff beats a padded one.
- **NEVER guess at "Exact Next Step."** If the chat ended mid-thought without a clear next action, ask the user: *"What's the next step you want logged?"*
- **NEVER merge projects.** One handoff = one project.
- **Specificity over brevity in next-step.** Exact commands, exact paths, exact URLs. The next Claude should be able to execute without thinking.
- **No preamble, no sign-off, no commentary outside the structure.** The output IS the handoff.
- **No emojis, no decorative formatting.** Plain structure.
